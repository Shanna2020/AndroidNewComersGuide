package com.example.android1finalproject.main.custom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;

import androidx.core.content.IntentCompat;

import com.example.android1finalproject.R;
import com.example.android1finalproject.community.CommunityActivity;
import com.example.android1finalproject.food.FoodActivity;
import com.example.android1finalproject.govtServices.GovtServicesActivity;
import com.example.android1finalproject.health.HealthActivity;
import com.example.android1finalproject.housing.HousingActivity;
import com.example.android1finalproject.localization.LocaleHelper;
import com.example.android1finalproject.main.CreateAccountActivity;
import com.example.android1finalproject.main.helper.Login;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class CustomMenu {
    private final Login login = new Login();
    private final FirebaseAuth mAuth;
    private final Context context;

    public CustomMenu(Context context) {
        mAuth = FirebaseAuth.getInstance();
        this.context = context;
    }

    public static void restart(Context context) {
        Intent mainIntent = IntentCompat.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_LAUNCHER);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.getApplicationContext().startActivity(mainIntent);
        System.exit(0);
    }

    public void showMenu(Activity a, View v, FirebaseAuth mAuth) {
        PopupMenu popupMenu = new PopupMenu(v.getContext(), v);

        try {
            Field[] fields = popupMenu.getClass().getDeclaredFields();
            for (Field field : fields) {
                if ("mPopup".equals(field.getName())) {
                    field.setAccessible(true);
                    Object menuPopupHelper = field.get(popupMenu);
                    Class<?> classPopupHelper = Class.forName(menuPopupHelper
                            .getClass().getName());
                    Method setForceIcons = classPopupHelper.getMethod(
                            "setForceShowIcon", boolean.class);
                    setForceIcons.invoke(menuPopupHelper, true);
                    break;
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }

        popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                if (menuItem.getItemId() == R.id.nav_community) {
                    Intent intent = new Intent(a, CommunityActivity.class);
                    a.startActivity(intent);
                }
                if (menuItem.getItemId() == R.id.nav_food) {
                    Intent intent = new Intent(a, FoodActivity.class);
                    a.startActivity(intent);
                }
                if (menuItem.getItemId() == R.id.nav_health) {
                    Intent intent = new Intent(a, HealthActivity.class);
                    a.startActivity(intent);
                }
                if (menuItem.getItemId() == R.id.nav_housing) {
                    Intent intent = new Intent(a, HousingActivity.class);
                    a.startActivity(intent);
                }
                if (menuItem.getItemId() == R.id.nav_govt) {
                    Intent intent = new Intent(a, GovtServicesActivity.class);
                    a.startActivity(intent);
                }

                if (menuItem.getItemId() == R.id.nav_change_language) {
                    changeLanguage();
                }
                if (menuItem.getItemId() == R.id.nav_sign_out)
                    login.signOut(a, mAuth);
                return true;
            }
        });
        popupMenu.show();

        Menu menu = popupMenu.getMenu();

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String email = user.getEmail();
            MenuItem signoutItem = menu.findItem(R.id.nav_sign_out);
            signoutItem.setTitle(R.string.sign_out + email);
        }
    }

    private void changeLanguage() {
        final int[] index = {0};
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.select_lang);
        String currentLanguage = LocaleHelper.getLanguage(context);
        String[] animals = {"English", "বাংলা", "اُردُو", "हिन्दी ", "官話 / 官话", "اَلْعَرَبِيَّةُ"};
        String[] langCode = {"en", "bn", "ur", "hi", "zh-rTW", "ar"};

        for (int i = 0; i < langCode.length; i++) {
            if (currentLanguage.equals(langCode[i])) {
                index[0] = i;
                break;
            }
        }

        builder.setSingleChoiceItems(animals, index[0], new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                index[0] = i;
            }
        });

        builder.setPositiveButton(R.string.ok_txt, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                LocaleHelper.setLocale(context, langCode[index[0]]);
                dialog.cancel();

                context.startActivity(new Intent(context, CreateAccountActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));

                //restart(context);
            }
        });
        builder.setNegativeButton(R.string.cancel_txt, null);

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
