package com.example.android1finalproject.education;

import android.content.Context;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.android1finalproject.R;
import com.example.android1finalproject.main.custom.CustomMenu;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.GeoPoint;

import java.util.ArrayList;

public class EducationActivity extends AppCompatActivity implements OnMapReadyCallback {
    MapView mapView;
    Button findBtn;
    EditText inputEt;
    ArrayList<Education> educationArrayList;
    ArrayList<Marker> markerArrayList;
    private FirebaseAuth mAuth;
    private CustomMenu customMenu;
    private GoogleMap mMap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_education);

        ImageView toolbar_menu = findViewById(R.id.toolbar_menu);
        TextView toolbar_title = findViewById(R.id.toolbar_title);

        mAuth = FirebaseAuth.getInstance();
        customMenu = new CustomMenu(this);

        toolbar_title.setText(R.string.education);

        toolbar_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customMenu.showMenu(EducationActivity.this, v, mAuth);
            }
        });

        educationArrayList = new ArrayList<>();
        markerArrayList = new ArrayList<>();

        mapView = findViewById(R.id.mapView);

        findBtn = findViewById(R.id.by_price);
        inputEt = findViewById(R.id.input);
        mapView.getMapAsync(this);
        mapView.onCreate(savedInstanceState);

        dummyData();


        findBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (inputEt.getText().toString().isEmpty()) {
                    inputEt.setError("Required");
                }

                String inputString = inputEt.getText().toString().trim();


                ArrayList<Education> tempList = new ArrayList<>();
                for (Education education :
                        educationArrayList) {
                    if (education.getName().trim().toLowerCase().contains(inputString.toLowerCase())) {
                        tempList.add(education);
                    }
                }
                loadMarkers(tempList, false);
                closeKeyboard();

            }
        });
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void dummyData() {
        educationArrayList.add(new Education(new GeoPoint(43.664486, -79.399689), "University of Toronto", "https://www.utoronto.ca/"));
        educationArrayList.add(new Education(new GeoPoint(43.7764, 79.2318), "Scarborough", "https://www.scarborough.gov.uk/"));
        educationArrayList.add(new Education(new GeoPoint(37.0965, 113.5684), "St George", "https://www.stgeorge.com.au/"));
        educationArrayList.add(new Education(new GeoPoint(43.65846945, -79.3789932724589), "Ryerson University", "https://www.ryerson.ca/"));
        educationArrayList.add(new Education(new GeoPoint(43.7734535, -79.50186839999998), "York University", "https://www.yorku.ca/"));
        educationArrayList.add(new Education(new GeoPoint(43.5789, -79.6583), "Humber College", "https://humber.ca/"));
        educationArrayList.add(new Education(new GeoPoint(43.664486, -79.699689), "Centennial College", "https://www.centennialcollege.ca/"));
        educationArrayList.add(new Education(new GeoPoint(43.6760, 79.4107), "George Brown College", "https://www.georgebrown.ca/"));
        educationArrayList.add(new Education(new GeoPoint(43.9542, 79.5198), "Seneca College", "https://www.senecacollege.ca/home.html"));

        //FirebaseFirestore db = FirebaseFirestore.getInstance();

//        for (int h = 0; h < houseArrayList.size(); h++) {
//            db.collection("houses").document(String.valueOf(h)).set(houseArrayList.get(h));
//        }

        /*db.collection("houses")
                .whereEqualTo("type", searchType)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("Firestore", document.getId() + " => " + document.getData());
                                houseArrayList.add(new House(document.getGeoPoint("geoPoint"), document.getString("name"), document.getDouble("price"), searchType));
                            }
                            loadMarkers(houseArrayList, true);
                        } else {
                            Log.d("Firestore", "Error getting documents: ", task.getException());
                        }
                    }
                });*/

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        loadMarkers(educationArrayList,true);
    }

    public void loadMarkers(ArrayList<Education> educations, boolean isAll) {
        removeMarkers();

        if (educations.isEmpty()) {
            Toast.makeText(EducationActivity.this, "No Education Institute Found", Toast.LENGTH_SHORT).show();
            return;
        }

        for (int i = 0; i < educations.size(); i++) {
            LatLng latLng = new LatLng(educations.get(i).getGeoPoint().getLatitude(), educations.get(i).getGeoPoint().getLongitude());

            String sb = educations.get(i).getName() + "\n\n" +
                    "Web:" + educations.get(i).getLink();
            Marker marker = mMap.addMarker(new MarkerOptions().position(latLng).title(sb));
            markerArrayList.add(marker);


            mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(@NonNull Marker marker) {
                    new AlertDialog.Builder(EducationActivity.this)
                            .setTitle("Info")
                            .setMessage(marker.getTitle())

                            .setNegativeButton("Close", null)
                            .show();
                    //Toast.makeText(HousingActivity3.this, marker.getTitle(), Toast.LENGTH_SHORT).show();
                    return false;
                }
            });
            if (isAll) {
                if (i == educations.size() - 1) {
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 10.0f));
                }
            } else {
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 10.0f));
            }
        }
    }

    private void removeMarkers() {
        if (!markerArrayList.isEmpty()) {
            for (Marker marker :
                    markerArrayList) {
                marker.remove();
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        mapView.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mapView.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState, @NonNull PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

}