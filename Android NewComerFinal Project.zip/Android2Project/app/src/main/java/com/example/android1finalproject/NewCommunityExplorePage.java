package com.example.android1finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class NewCommunityExplorePage extends AppCompatActivity {

    TextView titleTV, toolbar_title;
    Button exploreBTN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_community_explore_page);

        exploreBTN = findViewById(R.id.exploreBTN);
        exploreBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(NewCommunityExplorePage.this, ExploreMapActivity.class);
                intent.putExtra("type","tourism");
                startActivity(intent);
            }
        });
    }
}