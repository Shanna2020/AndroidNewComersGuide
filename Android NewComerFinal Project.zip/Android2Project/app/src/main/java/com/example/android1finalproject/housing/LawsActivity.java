package com.example.android1finalproject.housing;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.android1finalproject.R;

public class LawsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_laws);

//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayShowHomeEnabled(true);
//        getSupportActionBar().setTitle("Rules and Regulations");

        TextView rulesTextView = findViewById(R.id.rules);
        TextView toolbar_title = findViewById(R.id.toolbar_title);
        toolbar_title.setText(R.string.law);

        StringBuilder builder = new StringBuilder();

        builder.append(getString(R.string.txt_one).toString()).append("\n").append("\n");
        builder.append(getString(R.string.txt_two).toString()).append("\n").append("\n");
        builder.append(getString(R.string.txt_three).toString()).append("\n").append("\n");
        builder.append(getString(R.string.txt_four).toString()).append("\n").append("\n");
        builder.append(getString(R.string.txt_five).toString()).append("\n").append("\n");
        builder.append(getString(R.string.txt_six).toString()).append("\n").append("\n");
        builder.append(getString(R.string.txt_seven).toString()).append("\n").append("\n");
        builder.append(getString(R.string.text_eight).toString()).append("\n").append("\n");

        rulesTextView.setText(builder.toString());

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}