package com.example.android1finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Feedback extends AppCompatActivity {

    private EditText ouremail, name, message;
    Button sendBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        ouremail = findViewById(R.id.emailAddress);
        name = findViewById(R.id.nameData);
        message = findViewById(R.id.messageData);
        sendBtn = findViewById(R.id.sendButton);

        sendBtn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                String email = ouremail.getText().toString();
                String[] ouremailI =  email.split(",");
                String nameI = name.getText().toString();
                String messageI = message.getText().toString();
                //  Toast.makeText(view.getContext(),"IT SEND",Toast.LENGTH_LONG).show();
                Log.d("Message_XYZ", "onClick: "+ouremailI);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.putExtra(Intent.EXTRA_EMAIL, ouremailI);
                send.putExtra(Intent.EXTRA_SUBJECT, nameI);
                send.putExtra(Intent.EXTRA_TEXT, messageI);
                send.setType("message/rfc822");
                //  send.setClassName("com.google.android.gm", "com.google.android.gm.ConversationListActivity");

                send.setPackage("com.google.android.gm");


              /*  Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                        "mailto", "shanna_nikki@hotmail.com", null));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "This is my subject text");
                startActivity(emailIntent);
*/

                startActivity(send);


            }
        });
    }
}