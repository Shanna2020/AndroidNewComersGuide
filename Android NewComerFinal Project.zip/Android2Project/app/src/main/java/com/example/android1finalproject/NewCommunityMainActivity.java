package com.example.android1finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class NewCommunityMainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;


    Button byReligionBTN, byCultureBTN, readMoreBTN;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_community_main);

        setContentView(R.layout.activity_new_community_main);
     /*   ImageView toolbar_menu = findViewById(R.id.toolbar_menu);*/
      /*  TextView toolbar_title = findViewById(R.id.toolbar_title);*/

        mAuth = FirebaseAuth.getInstance();


        /*toolbar_title.setText("Community");*/



        byReligionBTN = findViewById(R.id.byReligionBTN);
        byCultureBTN = findViewById(R.id.byCultureBTN);
        readMoreBTN = findViewById(R.id.extraBTN);

        byReligionBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(NewCommunityMainActivity.this, CommunityByReligion.class);
                startActivity(intent);
            }
        });


        byCultureBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(NewCommunityMainActivity.this, CommunityByCulture.class);
                startActivity(intent);
            }
        });


        readMoreBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(NewCommunityMainActivity.this, NewCommunityExplorePage.class);
                startActivity(intent);
            }
        });

    }
}