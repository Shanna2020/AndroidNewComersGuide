# Android 01 Final Project - ITE-5333-RNA
## City Guide - GTA
### Group Members
Luiz Claro – N01459385 <br />
Priyadarshana Sarma – N01456748 <br />
Razwan Abdullah – N01390655 <br />
Shanna Russell – N01383085 <br />
Temitope Fisher – N01157120 <br />
