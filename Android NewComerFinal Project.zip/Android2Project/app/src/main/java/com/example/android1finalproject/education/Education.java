package com.example.android1finalproject.education;

import com.google.firebase.firestore.GeoPoint;

public class Education {
    GeoPoint geoPoint;
    String name;
    String link;

    public Education(GeoPoint geoPoint, String name, String link) {
        this.geoPoint = geoPoint;
        this.name = name;
        this.link = link;
    }

    public GeoPoint getGeoPoint() {
        return geoPoint;
    }

    public void setGeoPoint(GeoPoint geoPoint) {
        this.geoPoint = geoPoint;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
