package com.example.android1finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.android1finalproject.food.ByCountryActivityMain;
import com.example.android1finalproject.food.FoodMapActivity;
import com.example.android1finalproject.ReligionMapActivity;

public class CommunityByReligion extends AppCompatActivity {

    TextView titleTV, toolbar_title;
    Button christianBtn, islamBtn, hinduismBtn, buddhismBtn, judaismBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community_by_religion);


        toolbar_title = findViewById(R.id.toolbar_title);
        toolbar_title.setText("Religion");

        titleTV = findViewById(R.id.title_text);

        christianBtn = findViewById(R.id.btnChristian);
        islamBtn = findViewById(R.id.btnIslam);
        hinduismBtn = findViewById(R.id.btnHinduism);
        buddhismBtn = findViewById(R.id.btnBuddhism);
        judaismBtn = findViewById(R.id.btnJudaism);


        christianBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByReligion.this, ReligionMapActivity.class);
                intent.putExtra("type","christian");
                startActivity(intent);
            }
        });

        islamBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByReligion.this, ReligionMapActivity.class);
                intent.putExtra("type","islam");
                startActivity(intent);
            }
        });

        hinduismBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByReligion.this, ReligionMapActivity.class);
                intent.putExtra("type","hinduism");
                startActivity(intent);
            }
        });

        buddhismBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByReligion.this, ReligionMapActivity.class);
                intent.putExtra("type","buddhism");
                startActivity(intent);
            }
        });

        judaismBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByReligion.this, ReligionMapActivity.class);
                intent.putExtra("type","judaism");
                startActivity(intent);
            }
        });

    }
}