package com.example.android1finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class CommunityByCulture extends AppCompatActivity {

    TextView titleTV, toolbar_title;
    Button btnItaly, btnChinese, btnFrench, btnSpanish, btnIndia, btnJamo, btnFilipino, btnJew;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community_by_culture);

     /*   toolbar_title = findViewById(R.id.toolbar_title);
        toolbar_title.setText("Culture");

        titleTV = findViewById(R.id.title_text);*/

        btnItaly = findViewById(R.id.btnItaly);
        btnChinese = findViewById(R.id.btnChinese);
        btnFrench = findViewById(R.id.btnFrench);
        btnSpanish = findViewById(R.id.btnSpanish);
        btnIndia = findViewById(R.id.btnIndia);
        btnJamo = findViewById(R.id.btnJamo);
        btnFilipino = findViewById(R.id.btnFilipino);
        btnJew = findViewById(R.id.btnJew);

        btnItaly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByCulture.this, CommunityByCultureMap.class);
                intent.putExtra("type","italian");
                startActivity(intent);
            }
        });

        btnChinese.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByCulture.this, CommunityByCultureMap.class);
                intent.putExtra("type","chinese");
                startActivity(intent);
            }
        });

         btnFrench.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByCulture.this, CommunityByCultureMap.class);
                intent.putExtra("type","french");
                startActivity(intent);
            }
        });

        btnSpanish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByCulture.this, CommunityByCultureMap.class);
                intent.putExtra("type","spanish");
                startActivity(intent);
            }
        });

        btnIndia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByCulture.this, CommunityByCultureMap.class);
                intent.putExtra("type","indian");
                startActivity(intent);
            }
        });

        btnJamo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByCulture.this, CommunityByCultureMap.class);
                intent.putExtra("type","jamaican");
                startActivity(intent);
            }
        });

        btnFilipino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByCulture.this, CommunityByCultureMap.class);
                intent.putExtra("type","filipino");
                startActivity(intent);
            }
        });

        btnJew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CommunityByCulture.this, CommunityByCultureMap.class);
                intent.putExtra("type","jewish");
                startActivity(intent);
            }
        });
    }
}